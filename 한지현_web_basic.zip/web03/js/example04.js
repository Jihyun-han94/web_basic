function checknumber(element, text){
    
    if(isNaN(text)){
       
    }else if(text ) {
        element.style.backgroundColor = 'red';
        
    }
   
}

//value 값을 받으면 index 하나하나 숫자가 있는지 없는지 확인해야됨